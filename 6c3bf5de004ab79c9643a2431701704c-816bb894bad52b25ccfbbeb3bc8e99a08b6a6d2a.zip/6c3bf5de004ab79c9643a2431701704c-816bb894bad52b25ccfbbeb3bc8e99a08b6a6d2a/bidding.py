#TODO-1 : ASK USER FOR INPUT(NAME AND BID_AMOUNT)
#TODO-2 : STORE THE NAME AND PRICE INTO A DICTIONARY(name : price)
#TODO-3 : ASK IF THERE ARE ANY OTHER BIDDERS TO BID
# #TODO-4 : COMPARE THE BID AMOUNTS TO ANNOUNCE THE WINNER

def compare(bidding_dictionary):
    highest_amount = 0
    winner = ""
    for bidder in bidding_dictionary:
        bid_amount = bidding_dictionary[bidder]
        if bid_amount > highest_amount:
            highest_amount = bid_amount
            winner = bidder
    print(f"The winner is {winner} with bid amount {highest_amount}")

bids={}

continue_bidding = True
while continue_bidding:
    name = input("Enter your name:")
    price = int(input("Enter your price for bidding: $"))
    bids[name] = price
    wanna_continue = input("Type 'yes' to continue bidding, else type 'no': \n").lower()
    if wanna_continue == 'no':
        continue_bidding = False
        compare(bids)
    elif wanna_continue == 'yes':
        print("\n" * 30)




